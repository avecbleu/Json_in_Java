import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;
import org.glassfish.json.JsonProviderImpl;

public class ReadJsonFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String pathDeveloperFile = "src/developer.json";
		InputStream is = new FileInputStream(pathDeveloperFile);
		JsonReader jsonReader = Json.createReader(is);
		
		JsonObject object = jsonReader.readObject();
		jsonReader.close();
		is.close();
		
		Developer developer =new Developer();
		developer.setId(object.getInt("id"));
		developer.setName(object.getString("name"));
		developer.setRole(object.getString("role"));
		JsonArray arr = object.getJsonArray("languages");
		String[] languages = new String[arr.size()];
		int i= 0;
		for (JsonValue language: arr) {
			languages[i] = languages.toString();
			i++;
		
		}
		developer.setLanguages(languages);
		System.out.println(developer.toString());
		
		
	}

}
